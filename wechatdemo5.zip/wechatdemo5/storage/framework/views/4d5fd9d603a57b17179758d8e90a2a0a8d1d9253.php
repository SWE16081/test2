<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Larvuent</title>
</head>
<body>
<div id="app"></div>
<script src="../js/app.js"></script>
</body>
</html><?php /**PATH G:\phpStudyProject\PHPTutorial\WWW\wechatdemo5\resources\views/index.blade.php ENDPATH**/ ?>