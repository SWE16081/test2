<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class orprovepic extends Model
{
    //
    protected $table="orprovepic";
    protected $fillable=['orderid','cachetprove'];
}
