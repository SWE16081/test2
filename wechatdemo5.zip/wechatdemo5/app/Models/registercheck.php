<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class registercheck extends Model
{
    //
    protected $table="registercheck";
    protected $fillable=['makerid','state'];
}
