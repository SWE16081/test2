<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class cachetpic extends Model
{
    //
    protected $table='cachetpic';
    protected  $fillable=['cachetid','cachetPicPath'];
}
