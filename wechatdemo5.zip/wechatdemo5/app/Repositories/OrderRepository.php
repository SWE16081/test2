<?php
/**
 * Created by PhpStorm.
 * User: SWESWE
 * Date: 2019/9/30
 * Time: 19:49
 */

namespace App\Repositories;


class OrderRepository extends  BaseRepository
{

    public function modelname()
    {
        // TODO: Implement modelname() method.
        return 'order';
    }
    public function RepDataAddReturnId($data){
        $res=$this->model->insertGetId($data);
        return $res;
    }
    public function  RepDataAdd($data){
        return parent::dataAdd($data);
    }
    //按条件查询
    public function RepSelBy($name,$data,$columns = array('*')){
        return parent::findByGet($name,$data,$columns);
    }
    //双条件查询
    public function RepSelByTwo($name,$data,$columns = array('*')){
        return parent::findBy2($name,$data,$columns);
    }
    //按单条件更新数据
    public function RepUpdateByone($name,$value,$data)
    {
        return parent::updateBy($name,$value,$data);
    }
    //单条件删除
    public function RepDeleteByOne($name,$value){
        return parent::dataDelete($name,$value);
    }
}